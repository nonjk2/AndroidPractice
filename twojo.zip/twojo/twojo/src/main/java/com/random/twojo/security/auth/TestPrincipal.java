package com.random.twojo.security.auth;

import java.security.Principal;

public interface TestPrincipal extends Principal {

    public int getIdx();
}
